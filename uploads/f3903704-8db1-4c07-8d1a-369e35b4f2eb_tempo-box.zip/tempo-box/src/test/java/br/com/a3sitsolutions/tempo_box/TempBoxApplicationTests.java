package br.com.a3sitsolutions.tempo_box;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TempBoxApplicationTests {

	@Test
	void contextLoads() {
	}

}
